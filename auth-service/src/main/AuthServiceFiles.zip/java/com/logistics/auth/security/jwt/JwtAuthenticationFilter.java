package com.logistics.auth.security.jwt;

import com.logistics.auth.security.userdetails.CustomUserDetailsService;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

@Component
@RequiredArgsConstructor
public class JwtAuthenticationFilter extends OncePerRequestFilter {

	private final JwtService jwtService;
	private final CustomUserDetailsService customUserDetailsService;

	@Override
	protected void doFilterInternal(HttpServletRequest request,
	                                HttpServletResponse response,
	                                FilterChain filterChain)
	        throws ServletException, IOException {

	    String path = request.getServletPath();

	    if (path.equals("/api/v1/auth/login")
	            || path.equals("/api/v1/auth/register")
	            || path.equals("/api/v1/auth/refresh")
	            || path.equals("/api/v1/auth/logout")) {

	        filterChain.doFilter(request, response);
	        return;
	    }

	    final String authHeader = request.getHeader("Authorization");

	    if (authHeader == null || !authHeader.startsWith("Bearer ")) {
	        filterChain.doFilter(request, response);
	        return;
	    }

	    try {

	        String jwt = authHeader.substring(7);

	        String email = jwtService.extractUsername(jwt);

	        if (email != null &&
	                SecurityContextHolder.getContext().getAuthentication() == null) {

	            UserDetails userDetails =
	                    customUserDetailsService.loadUserByUsername(email);

	            if (jwtService.isTokenValid(jwt, userDetails)) {

	                UsernamePasswordAuthenticationToken authentication =
	                        new UsernamePasswordAuthenticationToken(
	                                userDetails,
	                                null,
	                                userDetails.getAuthorities());

	                authentication.setDetails(
	                        new WebAuthenticationDetailsSource()
	                                .buildDetails(request));

	                SecurityContextHolder.getContext()
	                        .setAuthentication(authentication);
	            }
	        }

	    } catch (Exception ex) {
	        SecurityContextHolder.clearContext();
	    }

	    filterChain.doFilter(request, response);
	}
}